<?php get_header(); ?>

    <section class="hero">
        <div class="wrap">
            <div class="hero__medias">
                <div class="hero__image">
                    <img src="<?php echo bloginfo('template_url'); ?>/images/capture.jpg" alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="grid section wrap">
        <h1 class="grid__title">
            Elisabeth Moss
            <small title="J'ai déjà gagné un oscar">🥇</small>
        </h1>
        <div class="grid__content o-typography">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum dolores voluptates suscipit accusantium voluptatum, delectus cum vel ipsa minus repellat aperiam beatae nostrum culpa asperiores placeat ab ipsum, cumque molestiae.</p>
        </div>
        <div class="grid__sidebar o-typography">
            <h3>Date de naissance</h3>
            <p>17 avril 1982</p>
            
            <h3>Nationalité</h3>
            <p>Canada</p>

            <h3>Page IMDB</h3>
            <a href="https://youtu.be/dQw4w9WgXcQ" target="_blank" rel="noopener">
                En savoir plus
            </a>
        </div>
    </section>

<?php get_footer(); ?>