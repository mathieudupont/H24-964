<?php

add_theme_support('post-thumbnails');
set_post_thumbnail_size(800, 480);
add_image_size('vignette', 220, 100, true);

function new_excerpt_length($length) {
    return 10; // Nombre de mots limite
}
add_filter('excerpt_length', 'new_excerpt_length');

// menu
register_nav_menus(array(
    'zone_menu_principale' => 'Zone principale'
));

// enlever les attributs width / height des balises images insérées
// avec the_post_thumbnail
function cw4_img_no_attributes( $html, $post_id, $post_image_id ) {
    $html = preg_replace( '/(width|height)=\"\d*\"\s/', "", $html );
    return $html;
}
add_filter('post_thumbnail_html', 'cw4_img_no_attributes', 10, 3);

// Register Custom Post Type
function cw4_films() {

	$labels = array(
		'name'                  => _x( 'Films', 'Post Type General Name', 'cinetim2' ),
		'singular_name'         => _x( 'Film', 'Post Type Singular Name', 'cinetim2' ),
		'menu_name'             => __( 'Films', 'cinetim2' ),
		'name_admin_bar'        => __( 'Post Type', 'cinetim2' ),
		'archives'              => __( 'Item Archives', 'cinetim2' ),
		'attributes'            => __( 'Item Attributes', 'cinetim2' ),
		'parent_item_colon'     => __( 'Parent Item:', 'cinetim2' ),
		'all_items'             => __( 'Tous les films', 'cinetim2' ),
		'add_new_item'          => __( 'Ajouter un film', 'cinetim2' ),
		'add_new'               => __( 'Ajouter un film', 'cinetim2' ),
		'new_item'              => __( 'Nouveau film', 'cinetim2' ),
		'edit_item'             => __( 'Éditer le film', 'cinetim2' ),
		'update_item'           => __( 'MAJ le film', 'cinetim2' ),
		'view_item'             => __( 'View Item', 'cinetim2' ),
		'view_items'            => __( 'View Items', 'cinetim2' ),
		'search_items'          => __( 'Search Item', 'cinetim2' ),
		'not_found'             => __( 'Not found', 'cinetim2' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'cinetim2' ),
		'featured_image'        => __( 'Featured Image', 'cinetim2' ),
		'set_featured_image'    => __( 'Set featured image', 'cinetim2' ),
		'remove_featured_image' => __( 'Remove featured image', 'cinetim2' ),
		'use_featured_image'    => __( 'Use as featured image', 'cinetim2' ),
		'insert_into_item'      => __( 'Insert into item', 'cinetim2' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'cinetim2' ),
		'items_list'            => __( 'Items list', 'cinetim2' ),
		'items_list_navigation' => __( 'Items list navigation', 'cinetim2' ),
		'filter_items_list'     => __( 'Filter items list', 'cinetim2' ),
	);
	$args = array(
		'label'                 => __( 'Film', 'cinetim2' ),
		'description'           => __( 'Films', 'cinetim2' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-editor-video',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
        'show_in_rest'          => true,
	);
	register_post_type( 'movies', $args );

}
add_action( 'init', 'cw4_films', 0 );



// Insérez vos CPT ici


