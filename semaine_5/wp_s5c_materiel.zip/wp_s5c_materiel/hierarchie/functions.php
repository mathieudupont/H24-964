<?php

//Gestion des menus
register_nav_menus(array(
    'menu_principal' => 'Menu principal'
)); 
