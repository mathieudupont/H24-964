<?php

//Gestion des menus
register_nav_menus(array(
    'zone_menu_principal' => 'Zone pour le menu principal'
)); 
