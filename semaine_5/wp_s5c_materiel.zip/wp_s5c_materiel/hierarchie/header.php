<html lang="fr">

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>
    <link rel="stylesheet" href="<?php bloginfo('template_url') ?>/css/style.css"/>
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <!-- Entête -->
    <header>

        <h1><?php the_title(); ?></h1>

        <!-- Navigation -->
        <?php wp_nav_menu( array(
            'theme_location'  => 'menu_principal',
            'container' => 'nav'
        )); ?>
    </header>