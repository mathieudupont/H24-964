class Main {
    constructor() {
        this.initPanel();
    }

    initPanel() {
        this.isPanelOpened = false;
        this.toggle = document.querySelector('[data-panel-toggle]');
        this.toggle.addEventListener('click', this.togglePanel);
    }

    togglePanel() {
        if (this.isPanelOpened) {
            this.isPanelOpened = false;
            document.documentElement.classList.remove('panel-is-active');
        } else {
            this.isPanelOpened = true;
            document.documentElement.classList.add('panel-is-active');
        }
    }
}

new Main();